package com.kaminga.reader.domain.usecase

import java.util.Locale

val IMAGE_EXTENSIONS: Set<String> = setOf("jpg", "jpeg", "png", "webp", "gif")

/** آیا این ورودی داخل ZIP یک عکس واقعی است؟ پوشه‌ها، فایل‌های مخفی و __MACOSX رد می‌شوند. */
fun isImageEntry(path: String): Boolean {
    if (path.endsWith("/")) return false
    val normalized = path.replace('\\', '/')
    if (normalized.startsWith("__MACOSX") || normalized.contains("/__MACOSX/")) return false
    val fileName = normalized.substringAfterLast('/')
    if (fileName.startsWith(".")) return false
    val extension = fileName.substringAfterLast('.', "").lowercase(Locale.US)
    return extension in IMAGE_EXTENSIONS
}

/** عنوان فصل از اسم فایل: پسوند و زیرخط‌ها برداشته می‌شود. */
fun chapterTitleFromFileName(name: String?): String {
    val base = name.orEmpty().substringAfterLast('/').substringBeforeLast('.', name.orEmpty().substringAfterLast('/'))
    val cleaned = base.replace('_', ' ').trim()
    return cleaned.ifEmpty { "فصل جدید" }
}
