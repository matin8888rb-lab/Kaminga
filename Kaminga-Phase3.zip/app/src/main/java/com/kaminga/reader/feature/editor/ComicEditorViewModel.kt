package com.kaminga.reader.feature.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kaminga.reader.core.common.UiMessages
import com.kaminga.reader.domain.model.ComicType
import com.kaminga.reader.domain.model.UserComic
import com.kaminga.reader.domain.repository.ChapterImporter
import com.kaminga.reader.domain.repository.UserLibraryRepository
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ComicEditorState(
    val isNew: Boolean = true,
    val isLoading: Boolean = false,
    val isBusy: Boolean = false,
    val title: String = "",
    val author: String = "",
    val summary: String = "",
    val type: ComicType = ComicType.MANGA,
    val coverPath: String? = null,
    val error: String? = null,
    val saved: Boolean = false
)

/** ساخت کمیک جدید (comicId = null) یا ویرایش کمیک شخصی. */
class ComicEditorViewModel(
    private val library: UserLibraryRepository,
    private val importer: ChapterImporter,
    private val comicId: String?,
    private val clock: () -> Long = { System.currentTimeMillis() }
) : ViewModel() {

    private val _state = MutableStateFlow(ComicEditorState(isNew = comicId == null, isLoading = comicId != null))
    val state: StateFlow<ComicEditorState> = _state.asStateFlow()

    private var original: UserComic? = null

    init {
        if (comicId != null) {
            viewModelScope.launch {
                val found = library.userComics.first().firstOrNull { it.id == comicId }
                original = found
                _state.value = if (found == null) {
                    ComicEditorState(isNew = false, isLoading = false, error = UiMessages.NOT_FOUND)
                } else {
                    ComicEditorState(
                        isNew = false,
                        title = found.title,
                        author = found.author,
                        summary = found.summary,
                        type = found.type,
                        coverPath = found.coverPath
                    )
                }
            }
        }
    }

    fun onTitleChange(value: String) = _state.update { it.copy(title = value, error = null) }
    fun onAuthorChange(value: String) = _state.update { it.copy(author = value) }
    fun onSummaryChange(value: String) = _state.update { it.copy(summary = value) }
    fun onTypeChange(value: ComicType) = _state.update { it.copy(type = value) }

    fun onCoverPicked(uri: String?) {
        if (uri == null) return
        viewModelScope.launch {
            _state.update { it.copy(isBusy = true, error = null) }
            importer.importCover(uri)
                .onSuccess { path ->
                    val previous = _state.value.coverPath
                    // کاور موقتی که هنوز ذخیره نشده بود پاک می‌شود؛ کاور اصلی تا لحظه‌ی ذخیره می‌ماند.
                    if (previous != null && previous != original?.coverPath) importer.deleteCover(previous)
                    _state.update { it.copy(coverPath = path, isBusy = false) }
                }
                .onFailure {
                    _state.update { it.copy(isBusy = false, error = UiMessages.COVER_FAILED) }
                }
        }
    }

    fun removeCover() {
        viewModelScope.launch {
            val previous = _state.value.coverPath
            if (previous != null && previous != original?.coverPath) importer.deleteCover(previous)
            _state.update { it.copy(coverPath = null) }
        }
    }

    fun save() {
        val current = _state.value
        if (current.isBusy || current.isLoading) return
        val title = current.title.trim()
        if (title.isEmpty()) {
            _state.update { it.copy(error = UiMessages.TITLE_REQUIRED) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(isBusy = true, error = null) }
            try {
                val old = original
                val comic = UserComic(
                    id = old?.id ?: "user-${UUID.randomUUID()}",
                    title = title,
                    author = current.author.trim(),
                    summary = current.summary.trim(),
                    type = current.type,
                    coverPath = current.coverPath,
                    createdAt = old?.createdAt ?: clock()
                )
                library.saveUserComic(comic)
                if (old?.coverPath != null && old.coverPath != comic.coverPath) importer.deleteCover(old.coverPath)
                original = comic
                _state.update { it.copy(isBusy = false, saved = true) }
            } catch (e: Exception) {
                _state.update { it.copy(isBusy = false, error = UiMessages.COMIC_SAVE_FAILED) }
            }
        }
    }

    /** با بستن بدون ذخیره، کاور تازه‌انتخاب‌شده پاک می‌شود. */
    fun discard() {
        val current = _state.value
        val cover = current.coverPath
        if (!current.saved && cover != null && cover != original?.coverPath) {
            viewModelScope.launch { importer.deleteCover(cover) }
        }
    }
}
