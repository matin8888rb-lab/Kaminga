package com.kaminga.reader.feature.editor

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaminga.reader.core.common.simpleFactory
import com.kaminga.reader.core.designsystem.CoverImage
import com.kaminga.reader.core.designsystem.KamingaChip
import com.kaminga.reader.core.designsystem.LoadingView
import com.kaminga.reader.di.AppContainer
import com.kaminga.reader.domain.model.ComicType
import com.kaminga.reader.ui.theme.Cyan
import com.kaminga.reader.ui.theme.Muted
import com.kaminga.reader.ui.theme.Night
import com.kaminga.reader.ui.theme.Panel

@Composable
fun ComicEditorScreen(
    comicId: String?,
    onClose: () -> Unit,
    viewModel: ComicEditorViewModel = viewModel(
        key = "editor-${comicId ?: "new"}",
        factory = simpleFactory {
            ComicEditorViewModel(AppContainer.userLibrary, AppContainer.chapterImporter, comicId)
        }
    )
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        viewModel.onCoverPicked(uri?.toString())
    }

    LaunchedEffect(state.saved) {
        if (state.saved) onClose()
    }

    val close = {
        viewModel.discard()
        onClose()
    }
    BackHandler { close() }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { close() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
            }
            Text(
                if (state.isNew) "کمیک جدید" else "ویرایش کمیک",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
        }
        if (state.isLoading) {
            LoadingView()
            return@Column
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CoverPicker(
                coverPath = state.coverPath,
                busy = state.isBusy,
                onPick = { coverPicker.launch(arrayOf("image/*")) },
                onRemove = viewModel::removeCover
            )
            OutlinedTextField(
                value = state.title,
                onValueChange = viewModel::onTitleChange,
                label = { Text("اسم کمیک") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = state.author,
                onValueChange = viewModel::onAuthorChange,
                label = { Text("نویسنده (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("نوع", color = Muted, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ComicType.entries.forEach { option ->
                    KamingaChip(option.label, state.type == option) { viewModel.onTypeChange(option) }
                }
            }
            OutlinedTextField(
                value = state.summary,
                onValueChange = viewModel::onSummaryChange,
                label = { Text("توضیحات (اختیاری)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            val error = state.error
            if (error != null) {
                Text(error, color = Cyan, fontSize = 13.sp)
            }
            Button(
                onClick = viewModel::save,
                enabled = !state.isBusy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)
            ) {
                Text(if (state.isBusy) "لطفاً صبر کن…" else "ذخیره", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CoverPicker(
    coverPath: String?,
    busy: Boolean,
    onPick: () -> Unit,
    onRemove: () -> Unit
) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(width = 150.dp, height = 210.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Panel)
                .clickable(enabled = !busy, onClick = onPick),
            contentAlignment = Alignment.Center
        ) {
            if (coverPath != null) {
                CoverImage(coverPath, Modifier.fillMaxSize(), description = "کاور")
            } else {
                Text("کاور", color = Muted, fontSize = 14.sp)
            }
        }
        Row(
            modifier = Modifier.padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = onPick, enabled = !busy) {
                Text(if (coverPath == null) "انتخاب کاور از گوشی" else "تغییر کاور")
            }
            if (coverPath != null) {
                OutlinedButton(onClick = onRemove, enabled = !busy) { Text("حذف کاور") }
            }
        }
    }
}
