package com.kaminga.reader.domain.repository

import com.kaminga.reader.domain.model.ImportedChapter
import com.kaminga.reader.domain.model.ReadingProgress
import com.kaminga.reader.domain.model.UserComic
import kotlinx.coroutines.flow.Flow

/** داده‌های شخصی کاربر روی همین گوشی: علاقه‌مندی‌ها، پیشرفت مطالعه و فصل‌های شخصی. */
interface UserLibraryRepository {
    val favoriteIds: Flow<Set<String>>

    /** کلید نقشه شناسه‌ی اثر است؛ برای هر اثر فقط آخرین جای مطالعه نگه داشته می‌شود. */
    val progress: Flow<Map<String, ReadingProgress>>
    val importedChapters: Flow<List<ImportedChapter>>

    /** کمیک‌هایی که کاربر خودش ساخته است. */
    val userComics: Flow<List<UserComic>>

    /** شناسه‌ی کمیک‌ها و فصل‌های نمایشی که کاربر حذف کرده است. */
    val hiddenIds: Flow<Set<String>>

    suspend fun setFavorite(comicId: String, favorite: Boolean)
    suspend fun saveProgress(progress: ReadingProgress)
    suspend fun addImportedChapter(chapter: ImportedChapter)
    suspend fun removeImportedChapter(chapterId: String)

    /** اگر شناسه از قبل باشد جایگزین می‌شود (ویرایش)، وگرنه اضافه می‌شود. */
    suspend fun saveUserComic(comic: UserComic)
    suspend fun removeUserComic(comicId: String)
    suspend fun hide(ids: Set<String>)
}
