package com.kaminga.reader.feature.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kaminga.reader.core.common.UiMessages
import com.kaminga.reader.core.common.UiState
import com.kaminga.reader.domain.model.Comic
import com.kaminga.reader.domain.model.ContinueItem
import com.kaminga.reader.domain.model.ReadingProgress
import com.kaminga.reader.domain.repository.ComicRepository
import com.kaminga.reader.domain.repository.UserLibraryRepository
import com.kaminga.reader.domain.usecase.buildContinueList
import com.kaminga.reader.domain.usecase.catalogChanges
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryContent(
    val favorites: List<Comic>,
    val history: List<ContinueItem>,
    val personal: List<Comic> = emptyList(),
    val hasDemos: Boolean = false
)

private fun toLibraryState(
    loaded: UiState<List<Comic>>,
    favoriteIds: Set<String>,
    progress: Map<String, ReadingProgress>
): UiState<LibraryContent> = when (loaded) {
    is UiState.Loading -> UiState.Loading
    is UiState.Error -> loaded
    is UiState.Success -> UiState.Success(
        LibraryContent(
            favorites = loaded.data.filter { it.id in favoriteIds },
            history = buildContinueList(loaded.data, progress),
            personal = loaded.data.filter { it.isPersonal }.sortedByDescending { it.addedOrder },
            hasDemos = loaded.data.any { it.isDemo }
        )
    )
}

class LibraryViewModel(
    private val repository: ComicRepository,
    private val library: UserLibraryRepository
) : ViewModel() {

    private val comics = MutableStateFlow<UiState<List<Comic>>>(UiState.Loading)

    val state: StateFlow<UiState<LibraryContent>> =
        combine(comics, library.favoriteIds, library.progress) { loaded, favorites, progress ->
            toLibraryState(loaded, favorites, progress)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Loading)

    init {
        load()
        viewModelScope.launch { library.catalogChanges().collect { fetch(showLoading = false) } }
    }

    fun load() = fetch(showLoading = true)

    /** همه‌ی کمیک‌های نمایشی را از فهرست برمی‌دارد؛ کمیک‌های شخصی دست‌نخورده می‌مانند. */
    fun removeAllDemos() {
        val demoIds = ((comics.value as? UiState.Success)?.data ?: return)
            .filter { it.isDemo }
            .map { it.id }
            .toSet()
        viewModelScope.launch { library.hide(demoIds) }
    }

    private fun fetch(showLoading: Boolean) {
        if (showLoading) comics.value = UiState.Loading
        viewModelScope.launch {
            repository.getComics()
                .onSuccess { list -> comics.value = UiState.Success(list) }
                .onFailure { comics.value = UiState.Error(UiMessages.LOAD_FAILED) }
        }
    }
}
