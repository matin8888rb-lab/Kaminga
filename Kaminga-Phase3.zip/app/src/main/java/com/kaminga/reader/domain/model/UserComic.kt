package com.kaminga.reader.domain.model

/** کمیکی که خود کاربر روی همین گوشی ساخته است (اسم، کاور و فصل‌های شخصی). */
data class UserComic(
    val id: String,
    val title: String,
    val author: String,
    val summary: String,
    val type: ComicType,
    val coverPath: String?,
    val createdAt: Long
)

private val USER_ACCENTS = longArrayOf(
    0xFF3B2A6B, 0xFF1F4E5F, 0xFF5B2A4A, 0xFF2D5A3D, 0xFF5A3B1F, 0xFF2A3F6B
)

fun UserComic.toComic(order: Int): Comic {
    val shownAuthor = author.ifBlank { "نامشخص" }
    return Comic(
        id = id,
        title = title,
        originalTitle = "",
        summary = summary,
        type = type,
        genres = emptyList(),
        author = shownAuthor,
        artist = shownAuthor,
        language = ComicLanguage.FA,
        status = PublicationStatus.ONGOING,
        addedOrder = order,
        accentColor = USER_ACCENTS[(id.hashCode() and Int.MAX_VALUE) % USER_ACCENTS.size],
        coverPath = coverPath,
        isPersonal = true
    )
}
