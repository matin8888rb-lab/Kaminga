package com.kaminga.reader.core.designsystem

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.kaminga.reader.feature.reader.PageBitmapLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** کاور کمیک از فایل داخل حافظه‌ی برنامه؛ تا آماده شدن تصویر جای خالی نشان می‌دهد. */
@Composable
fun CoverImage(
    path: String,
    modifier: Modifier = Modifier,
    description: String? = null,
    targetWidthPx: Int = 600
) {
    val bitmap by produceState<ImageBitmap?>(null, path, targetWidthPx) {
        value = withContext(Dispatchers.IO) { PageBitmapLoader.load(path, targetWidthPx)?.asImageBitmap() }
    }
    val image = bitmap
    if (image != null) {
        Image(
            bitmap = image,
            contentDescription = description,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(modifier)
    }
}
