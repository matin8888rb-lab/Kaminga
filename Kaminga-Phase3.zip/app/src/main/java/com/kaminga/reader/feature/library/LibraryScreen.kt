package com.kaminga.reader.feature.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaminga.reader.core.common.UiState
import com.kaminga.reader.core.common.simpleFactory
import com.kaminga.reader.core.designsystem.ComicRow
import com.kaminga.reader.core.designsystem.EmptyView
import com.kaminga.reader.core.designsystem.ErrorView
import com.kaminga.reader.core.designsystem.KamingaChip
import com.kaminga.reader.core.designsystem.LoadingView
import com.kaminga.reader.di.AppContainer
import com.kaminga.reader.ui.theme.Cyan
import com.kaminga.reader.ui.theme.Muted
import com.kaminga.reader.ui.theme.Night
import com.kaminga.reader.domain.usecase.describe

private enum class LibrarySection(val label: String) {
    MY_COMICS("کمیک‌های من"),
    FAVORITES("علاقه‌مندی‌ها"),
    HISTORY("ادامه‌ی مطالعه")
}

@Composable
fun LibraryScreen(
    onComicClick: (String) -> Unit,
    onContinueClick: (String, String) -> Unit,
    onAddComic: () -> Unit,
    viewModel: LibraryViewModel = viewModel(
        factory = simpleFactory { LibraryViewModel(AppContainer.comicRepository, AppContainer.userLibrary) }
    )
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var section by rememberSaveable { mutableStateOf(LibrarySection.MY_COMICS) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "کتابخانه‌ی من",
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 22.dp)
        )
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LibrarySection.entries.forEach { option ->
                KamingaChip(option.label, section == option) { section = option }
            }
        }
        when (val current = state) {
            is UiState.Loading -> LoadingView()
            is UiState.Error -> ErrorView(
                message = current.message,
                onRetry = if (current.retryable) viewModel::load else null
            )
            is UiState.Success -> LibraryList(
                content = current.data,
                section = section,
                onComicClick = onComicClick,
                onContinueClick = onContinueClick,
                onAddComic = onAddComic,
                onRemoveDemos = viewModel::removeAllDemos
            )
        }
    }
}

@Composable
private fun LibraryList(
    content: LibraryContent,
    section: LibrarySection,
    onComicClick: (String) -> Unit,
    onContinueClick: (String, String) -> Unit,
    onAddComic: () -> Unit,
    onRemoveDemos: () -> Unit
) {
    if (section == LibrarySection.MY_COMICS) {
        MyComics(content, onComicClick, onAddComic, onRemoveDemos)
    } else if (section == LibrarySection.FAVORITES) {
        if (content.favorites.isEmpty()) {
            EmptyView(
                icon = Icons.Default.Favorite,
                title = "هنوز اثری در علاقه‌مندی‌ها نیست",
                body = "در صفحه‌ی هر اثر روی قلب بزن تا این‌جا بیاید."
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(content.favorites, key = { comic -> "fav-${comic.id}" }) { comic ->
                    ComicRow(comic = comic, onClick = { onComicClick(comic.id) })
                }
            }
        }
    } else {
        if (content.history.isEmpty()) {
            EmptyView(
                icon = Icons.Default.Info,
                title = "هنوز مطالعه‌ای شروع نکرده‌ای",
                body = "بعد از باز کردن یک فصل، جای مطالعه‌ات این‌جا ذخیره می‌شود."
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(content.history, key = { entry -> "history-${entry.comic.id}" }) { entry ->
                    ComicRow(
                        comic = entry.comic,
                        onClick = { onContinueClick(entry.comic.id, entry.progress.chapterId) },
                        subtitle = entry.progress.describe()
                    )
                }
            }
        }
    }
}

@Composable
private fun MyComics(
    content: LibraryContent,
    onComicClick: (String) -> Unit,
    onAddComic: () -> Unit,
    onRemoveDemos: () -> Unit
) {
    var confirmRemoveDemos by remember { mutableStateOf(false) }
    if (confirmRemoveDemos) {
        AlertDialog(
            onDismissRequest = { confirmRemoveDemos = false },
            title = { Text("حذف همه‌ی کمیک‌های نمایشی؟") },
            text = { Text("فقط کمیک‌های نمایشی از فهرست برداشته می‌شوند. کمیک‌هایی که خودت ساخته‌ای می‌مانند.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemoveDemos = false
                    onRemoveDemos()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmRemoveDemos = false }) { Text("انصراف") } }
        )
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(
                onClick = onAddComic,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text("  کمیک جدید", fontWeight = FontWeight.Bold)
            }
        }
        if (content.personal.isEmpty()) {
            item {
                Text(
                    "هنوز کمیکی نساخته‌ای. با دکمه‌ی بالا اسم و کاور بگذار، بعد از صفحه‌ی کمیک فصل‌ها را از عکس یا فایل ZIP / CBZ اضافه کن.",
                    color = Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
        items(content.personal, key = { comic -> "mine-${comic.id}" }) { comic ->
            ComicRow(comic = comic, onClick = { onComicClick(comic.id) })
        }
        if (content.hasDemos) {
            item {
                TextButton(onClick = { confirmRemoveDemos = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("پاک کردن همه‌ی کمیک‌های نمایشی", color = Muted)
                }
            }
        }
    }
}
