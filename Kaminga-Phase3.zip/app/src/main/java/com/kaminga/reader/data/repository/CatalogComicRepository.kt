package com.kaminga.reader.data.repository

import com.kaminga.reader.domain.model.Comic
import com.kaminga.reader.domain.repository.ComicNotFoundException
import com.kaminga.reader.domain.repository.ComicRepository
import com.kaminga.reader.domain.repository.UserLibraryRepository
import com.kaminga.reader.domain.usecase.buildCatalog
import kotlinx.coroutines.flow.first

/**
 * مخزن اصلی را با تغییرات کاربر ترکیب می‌کند: حذف کمیک و فصل نمایشی
 * و اضافه شدن کمیک‌هایی که خود کاربر ساخته است.
 */
class CatalogComicRepository(
    private val base: ComicRepository,
    private val library: UserLibraryRepository
) : ComicRepository {

    override suspend fun getComics(): Result<List<Comic>> {
        val loaded = base.getComics().getOrElse { return Result.failure(it) }
        val catalog = buildCatalog(loaded, library.userComics.first(), library.hiddenIds.first())
        return Result.success(catalog)
    }

    override suspend fun getComic(id: String): Result<Comic> {
        val all = getComics().getOrElse { return Result.failure(it) }
        val comic = all.firstOrNull { it.id == id }
        return if (comic != null) Result.success(comic) else Result.failure(ComicNotFoundException(id))
    }
}
