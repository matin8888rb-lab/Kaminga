package com.kaminga.reader.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.kaminga.reader.domain.model.ImportedChapter
import com.kaminga.reader.domain.repository.ArchiveImportResult
import com.kaminga.reader.domain.repository.ChapterImporter
import com.kaminga.reader.domain.usecase.chapterTitleFromFileName
import com.kaminga.reader.domain.usecase.isImageEntry
import com.kaminga.reader.domain.usecase.naturalCompare
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException

/**
 * عکس‌های انتخاب‌شده را داخل حافظه‌ی خصوصی برنامه کپی می‌کند. این‌طوری بعد از بستن
 * برنامه هم در دسترس‌اند و به مجوز دائمی فایل‌ها (که محدودیت تعداد دارد) نیازی نیست.
 */
class FileChapterImporter(context: Context) : ChapterImporter {

    private val appContext: Context = context.applicationContext
    private val rootDir: File = File(appContext.filesDir, "imported")
    private val coverDir: File = File(appContext.filesDir, "covers")

    private class Source(val uri: Uri, val name: String, val mime: String)

    override suspend fun importChapter(
        comicId: String,
        sourceUris: List<String>,
        title: String
    ): Result<ImportedChapter> = withContext(Dispatchers.IO) {
        val chapterId = UUID.randomUUID().toString()
        val dir = File(rootDir, chapterId)
        try {
            Result.success(copyPages(chapterId, comicId, title, sourceUris, dir))
        } catch (e: CancellationException) {
            dir.deleteRecursively()
            throw e
        } catch (e: Exception) {
            dir.deleteRecursively()
            Result.failure(e)
        }
    }

    override suspend fun deleteFiles(pagePaths: List<String>) {
        withContext(Dispatchers.IO) {
            val parent = pagePaths.firstOrNull()?.let { File(it).parentFile } ?: return@withContext
            // فقط داخل پوشه‌ی خود برنامه پاک می‌کنیم.
            if (parent.absolutePath.startsWith(rootDir.absolutePath)) {
                parent.deleteRecursively()
            }
        }
    }

    override suspend fun importArchives(comicId: String, sourceUris: List<String>): ArchiveImportResult =
        withContext(Dispatchers.IO) {
            val named = sourceUris
                .map { raw -> raw to (displayName(Uri.parse(raw)) ?: raw.substringAfterLast('/')) }
                .sortedWith(Comparator { a, b -> naturalCompare(a.second, b.second) })
            val chapters = ArrayList<ImportedChapter>()
            val failed = ArrayList<String>()
            val baseTime = System.currentTimeMillis()
            named.forEachIndexed { index, (raw, name) ->
                val chapterId = UUID.randomUUID().toString()
                val dir = File(rootDir, chapterId)
                try {
                    val paths = unzipPages(Uri.parse(raw), dir)
                    chapters.add(
                        ImportedChapter(chapterId, comicId, chapterTitleFromFileName(name), paths, baseTime + index)
                    )
                } catch (e: CancellationException) {
                    dir.deleteRecursively()
                    throw e
                } catch (e: Exception) {
                    dir.deleteRecursively()
                    failed.add(name)
                }
            }
            ArchiveImportResult(chapters, failed)
        }

    /** عکس‌های داخل ZIP را استخراج می‌کند، به ترتیب طبیعی اسم مرتب می‌کند و page_0001... نام‌گذاری می‌کند. */
    private fun unzipPages(uri: Uri, dir: File): List<String> {
        if (!dir.mkdirs() && !dir.isDirectory) throw IOException("Cannot create folder.")
        val input = appContext.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open archive.")
        val found = ArrayList<Pair<String, File>>()
        input.use { raw ->
            ZipInputStream(raw.buffered()).use { zip ->
                var counter = 0
                while (found.size < MAX_ARCHIVE_PAGES) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory || !isImageEntry(entry.name)) continue
                    val extension = entry.name.substringAfterLast('.').lowercase(Locale.US)
                    val temp = File(dir, "tmp_${counter++}.$extension")
                    if (copyLimited(zip, temp, MAX_FILE_BYTES)) {
                        temp.delete()
                    } else {
                        found.add(entry.name to temp)
                    }
                }
            }
        }
        require(found.isNotEmpty()) { "No images inside the archive." }
        val sorted = found.sortedWith(Comparator { a, b -> naturalCompare(a.first, b.first) })
        val paths = ArrayList<String>(sorted.size)
        sorted.forEachIndexed { index, (_, temp) ->
            val extension = temp.extension
            val target = File(dir, String.format(Locale.US, "page_%04d.%s", index + 1, extension))
            if (!temp.renameTo(target)) throw IOException("Cannot rename page.")
            paths.add(target.absolutePath)
        }
        return paths
    }

    /** true یعنی فایل از حد مجاز بزرگ‌تر بود و کامل ذخیره نشد. */
    private fun copyLimited(input: InputStream, target: File, limit: Long): Boolean {
        var total = 0L
        var exceeded = false
        val buffer = ByteArray(16 * 1024)
        target.outputStream().use { output ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > limit) {
                    exceeded = true
                    break
                }
                output.write(buffer, 0, read)
            }
        }
        return exceeded
    }

    override suspend fun importCover(sourceUri: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(sourceUri)
            val resolver = appContext.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val boundsStream = resolver.openInputStream(uri) ?: throw IOException("Cannot open image.")
            boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) throw IOException("Not an image.")
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= COVER_WIDTH) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val imageStream = resolver.openInputStream(uri) ?: throw IOException("Cannot open image.")
            val bitmap = imageStream.use { BitmapFactory.decodeStream(it, null, options) }
                ?: throw IOException("Cannot decode image.")
            if (!coverDir.mkdirs() && !coverDir.isDirectory) throw IOException("Cannot create folder.")
            val file = File(coverDir, "${UUID.randomUUID()}.jpg")
            file.outputStream().use { output -> bitmap.compress(Bitmap.CompressFormat.JPEG, 88, output) }
            bitmap.recycle()
            Result.success(file.absolutePath)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteCover(path: String?) {
        if (path.isNullOrEmpty()) return
        withContext(Dispatchers.IO) {
            val file = File(path)
            // فقط داخل پوشه‌ی کاور خود برنامه پاک می‌کنیم.
            if (file.absolutePath.startsWith(coverDir.absolutePath)) file.delete()
        }
    }

    private fun copyPages(
        chapterId: String,
        comicId: String,
        title: String,
        rawUris: List<String>,
        dir: File
    ): ImportedChapter {
        val resolver = appContext.contentResolver
        val sources = rawUris.mapNotNull { raw ->
            val uri = Uri.parse(raw)
            val mime = resolver.getType(uri)
            if (mime != null && mime.startsWith("image/")) {
                Source(uri, displayName(uri) ?: raw.substringAfterLast('/'), mime)
            } else {
                null
            }
        }
        require(sources.isNotEmpty()) { "No image files were selected." }

        val sorted = sources
            .sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })
            .take(MAX_PAGES)

        if (!dir.mkdirs() && !dir.isDirectory) throw IOException("Cannot create folder.")

        val paths = ArrayList<String>(sorted.size)
        sorted.forEachIndexed { index, source ->
            val target = File(dir, String.format(Locale.US, "page_%04d.%s", index + 1, extensionFor(source.mime)))
            val input = resolver.openInputStream(source.uri) ?: throw IOException("Cannot open image.")
            input.use { stream -> target.outputStream().use { output -> stream.copyTo(output) } }
            if (target.length() > MAX_FILE_BYTES) {
                target.delete()
            } else {
                paths.add(target.absolutePath)
            }
        }
        require(paths.isNotEmpty()) { "No usable images." }

        return ImportedChapter(chapterId, comicId, title, paths, System.currentTimeMillis())
    }

    private fun displayName(uri: Uri): String? =
        appContext.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }

    private fun extensionFor(mime: String): String = when (mime) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        else -> "jpg"
    }

    private companion object {
        const val MAX_PAGES = 300
        const val MAX_ARCHIVE_PAGES = 600
        const val COVER_WIDTH = 600
        const val MAX_FILE_BYTES = 30L * 1024L * 1024L
    }
}
