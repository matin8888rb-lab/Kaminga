package com.kaminga.reader.domain.usecase

import com.kaminga.reader.domain.model.Comic
import com.kaminga.reader.domain.model.UserComic
import com.kaminga.reader.domain.model.toComic
import com.kaminga.reader.domain.repository.UserLibraryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop

/**
 * فهرست نهایی آثار: کمیک‌ها و فصل‌های مخفی‌شده (حذف‌شده‌ی کاربر) برداشته می‌شوند
 * و کمیک‌های شخصی کاربر بعد از آن‌ها، به‌عنوان جدیدترین، اضافه می‌شوند.
 */
fun buildCatalog(base: List<Comic>, userComics: List<UserComic>, hidden: Set<String>): List<Comic> {
    val visible = base
        .filterNot { it.id in hidden }
        .map { comic -> comic.copy(chapters = comic.chapters.filterNot { it.id in hidden }) }
    val startOrder = (base.maxOfOrNull { it.addedOrder } ?: 0) + 1
    val mine = userComics
        .sortedBy { it.createdAt }
        .mapIndexed { index, item -> item.toComic(startOrder + index) }
    return visible + mine
}

/** هر بار فهرست کمیک‌های شخصی یا مخفی‌ها عوض شود یک رویداد می‌دهد (اولین مقدار نادیده گرفته می‌شود). */
fun UserLibraryRepository.catalogChanges(): Flow<Unit> =
    combine(userComics, hiddenIds) { _, _ -> Unit }.drop(1)
