package com.kaminga.reader.domain.repository

import com.kaminga.reader.domain.model.ImportedChapter

/** نتیجه‌ی افزودن چند فایل ZIP/CBZ: فصل‌های ساخته‌شده و اسم فایل‌هایی که خوانده نشدند. */
data class ArchiveImportResult(
    val chapters: List<ImportedChapter>,
    val failedFiles: List<String>
)

interface ChapterImporter {
    /** عکس‌های انتخاب‌شده را به حافظه‌ی برنامه کپی می‌کند و یک فصل می‌سازد. */
    suspend fun importChapter(
        comicId: String,
        sourceUris: List<String>,
        title: String
    ): Result<ImportedChapter>

    /** هر فایل ZIP/CBZ یک فصل می‌شود. فایل‌ها به ترتیب طبیعی اسم پردازش می‌شوند. */
    suspend fun importArchives(comicId: String, sourceUris: List<String>): ArchiveImportResult

    /** یک عکس را برای کاور کوچک و در حافظه‌ی برنامه ذخیره می‌کند و مسیرش را برمی‌گرداند. */
    suspend fun importCover(sourceUri: String): Result<String>

    suspend fun deleteCover(path: String?)

    suspend fun deleteFiles(pagePaths: List<String>)
}
