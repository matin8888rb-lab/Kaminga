package com.kaminga.reader.domain

import com.kaminga.reader.domain.model.Chapter
import com.kaminga.reader.domain.model.ComicType
import com.kaminga.reader.domain.model.UserComic
import com.kaminga.reader.domain.usecase.buildCatalog
import com.kaminga.reader.domain.usecase.chapterTitleFromFileName
import com.kaminga.reader.domain.usecase.isImageEntry
import com.kaminga.reader.testutil.sampleComic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogTest {

    private fun mine(id: String, createdAt: Long) =
        UserComic(id, "کمیک $id", "", "", ComicType.MANGA, null, createdAt)

    @Test
    fun hiddenComicsAndChaptersAreRemoved() {
        val withChapters = sampleComic(id = "a").copy(
            chapters = listOf(Chapter("a-1", 1, "یک", 3), Chapter("a-2", 2, "دو", 3))
        )
        val result = buildCatalog(listOf(withChapters, sampleComic(id = "b")), emptyList(), setOf("b", "a-1"))
        assertEquals(listOf("a"), result.map { it.id })
        assertEquals(listOf("a-2"), result.single().chapters.map { it.id })
    }

    @Test
    fun userComicsComeAfterAndAreNewest() {
        val result = buildCatalog(
            listOf(sampleComic(id = "a", addedOrder = 5)),
            listOf(mine("u2", 20L), mine("u1", 10L)),
            emptySet()
        )
        assertEquals(listOf("a", "u1", "u2"), result.map { it.id })
        assertTrue(result[1].isPersonal)
        assertFalse(result[0].isPersonal)
        assertTrue(result[1].addedOrder > 5)
        assertTrue(result[2].addedOrder > result[1].addedOrder)
    }

    @Test
    fun hidingEverythingLeavesOnlyUserComics() {
        val result = buildCatalog(listOf(sampleComic(id = "a")), listOf(mine("u1", 1L)), setOf("a"))
        assertEquals(listOf("u1"), result.map { it.id })
    }

    @Test
    fun imageEntriesAreFilteredByName() {
        assertTrue(isImageEntry("ch1/001.JPG"))
        assertTrue(isImageEntry("page.webp"))
        assertFalse(isImageEntry("ch1/"))
        assertFalse(isImageEntry("__MACOSX/ch1/001.jpg"))
        assertFalse(isImageEntry("ch1/.hidden.jpg"))
        assertFalse(isImageEntry("info.txt"))
        assertFalse(isImageEntry("noextension"))
    }

    @Test
    fun chapterTitleComesFromFileName() {
        assertEquals("ch01", chapterTitleFromFileName("ch01.cbz"))
        assertEquals("Naruto vol 1", chapterTitleFromFileName("Naruto_vol_1.zip"))
        assertEquals("فصل جدید", chapterTitleFromFileName(null))
        assertEquals("فصل جدید", chapterTitleFromFileName(""))
    }
}
