package com.kaminga.reader.feature

import com.kaminga.reader.core.common.UiMessages
import com.kaminga.reader.core.common.UiState
import com.kaminga.reader.domain.model.Chapter
import com.kaminga.reader.domain.model.ComicType
import com.kaminga.reader.domain.model.UserComic
import com.kaminga.reader.feature.details.DetailsViewModel
import com.kaminga.reader.feature.details.archiveMessage
import com.kaminga.reader.feature.editor.ComicEditorViewModel
import com.kaminga.reader.feature.library.LibraryViewModel
import com.kaminga.reader.testutil.FakeChapterImporter
import com.kaminga.reader.testutil.FakeComicRepository
import com.kaminga.reader.testutil.InMemoryUserLibraryRepository
import com.kaminga.reader.testutil.MainDispatcherRule
import com.kaminga.reader.testutil.sampleComic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class Phase3Test {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private val demo = sampleComic("a").copy(
        isDemo = true,
        chapters = listOf(Chapter("a-1", 1, "یک", pageCount = 5), Chapter("a-2", 2, "دو", pageCount = 5))
    )

    private fun detailsVm(
        library: InMemoryUserLibraryRepository,
        importer: FakeChapterImporter = FakeChapterImporter(),
        id: String = "a"
    ) = DetailsViewModel(FakeComicRepository(listOf(demo)), library, importer, id)

    @Test
    fun archivesBecomeOneChapterEach() {
        val library = InMemoryUserLibraryRepository()
        val vm = detailsVm(library)
        vm.importArchives(listOf("ch1.zip", "ch2.zip"))
        assertEquals(2, library.currentImported.size)
        assertEquals("2 فصل اضافه شد.", vm.importState.value.message)
        assertEquals(4, (vm.state.value as UiState.Success).data.comic.chapters.size)
    }

    @Test
    fun archiveMessageMentionsFailedFiles() {
        val text = archiveMessage(1, listOf("bad.cbr"))
        assertTrue(text.contains("1 فصل اضافه شد."))
        assertTrue(text.contains("bad.cbr"))
        assertEquals(UiMessages.IMPORT_FAILED, archiveMessage(0, emptyList()))
    }

    @Test
    fun deletingBuiltInChapterOnlyHidesIt() {
        val library = InMemoryUserLibraryRepository()
        val importer = FakeChapterImporter()
        val vm = detailsVm(library, importer)
        val first = (vm.state.value as UiState.Success).data.comic.chapters.first()
        vm.deleteChapter(first)
        assertEquals(setOf("a-1"), library.currentHidden)
        assertTrue(importer.deleted.isEmpty())
    }

    @Test
    fun deletingDemoComicHidesItAndFinishes() {
        val library = InMemoryUserLibraryRepository()
        val vm = detailsVm(library)
        vm.deleteComic()
        assertEquals(setOf("a"), library.currentHidden)
        assertTrue(vm.finished.value)
    }

    @Test
    fun deletingPersonalComicRemovesChaptersCoverAndRecord() {
        val library = InMemoryUserLibraryRepository()
        val importer = FakeChapterImporter()
        val mine = UserComic("u1", "من", "", "", ComicType.MANGA, "/covers/x.jpg", 1L)
        val repo = FakeComicRepository(listOf(demo, sampleComic("u1").copy(isPersonal = true, coverPath = mine.coverPath)))
        kotlinx.coroutines.runBlocking { library.saveUserComic(mine) }
        val vm = DetailsViewModel(repo, library, importer, "u1")
        vm.importChapter(listOf("p1", "p2"))
        vm.deleteComic()
        assertTrue(library.currentUserComics.isEmpty())
        assertTrue(library.currentImported.isEmpty())
        assertEquals(listOf<String?>("/covers/x.jpg"), importer.deletedCovers)
        assertTrue(vm.finished.value)
    }

    @Test
    fun libraryRemovesOnlyDemos() {
        val library = InMemoryUserLibraryRepository()
        val repo = FakeComicRepository(listOf(demo, sampleComic("u1").copy(isPersonal = true)))
        val vm = LibraryViewModel(repo, library)
        val content = (vm.state.value as UiState.Success).data
        assertTrue(content.hasDemos)
        assertEquals(listOf("u1"), content.personal.map { it.id })
        vm.removeAllDemos()
        assertEquals(setOf("a"), library.currentHidden)
    }

    // --- Editor ---

    @Test
    fun editorRequiresTitle() {
        val library = InMemoryUserLibraryRepository()
        val vm = ComicEditorViewModel(library, FakeChapterImporter(), null)
        vm.save()
        assertEquals(UiMessages.TITLE_REQUIRED, vm.state.value.error)
        assertTrue(library.currentUserComics.isEmpty())
    }

    @Test
    fun editorCreatesComicWithCover() {
        val library = InMemoryUserLibraryRepository()
        val vm = ComicEditorViewModel(library, FakeChapterImporter(), null, clock = { 55L })
        vm.onTitleChange("  کمیک من  ")
        vm.onTypeChange(ComicType.WEBTOON)
        vm.onCoverPicked("pic")
        vm.save()
        val saved = library.currentUserComics.single()
        assertEquals("کمیک من", saved.title)
        assertEquals(ComicType.WEBTOON, saved.type)
        assertEquals("/covers/pic.jpg", saved.coverPath)
        assertEquals(55L, saved.createdAt)
        assertTrue(saved.id.startsWith("user-"))
        assertTrue(vm.state.value.saved)
    }

    @Test
    fun editorShowsErrorWhenCoverFails() {
        val vm = ComicEditorViewModel(InMemoryUserLibraryRepository(), FakeChapterImporter(RuntimeException("bad")), null)
        vm.onCoverPicked("pic")
        assertEquals(UiMessages.COVER_FAILED, vm.state.value.error)
        assertNull(vm.state.value.coverPath)
    }

    @Test
    fun editorUpdatesExistingComicAndDeletesOldCover() {
        val library = InMemoryUserLibraryRepository()
        val importer = FakeChapterImporter()
        kotlinx.coroutines.runBlocking {
            library.saveUserComic(UserComic("u1", "قدیمی", "ا", "", ComicType.MANGA, "/covers/old.jpg", 9L))
        }
        val vm = ComicEditorViewModel(library, importer, "u1")
        assertEquals("قدیمی", vm.state.value.title)
        vm.onTitleChange("جدید")
        vm.onCoverPicked("new")
        vm.save()
        val saved = library.currentUserComics.single()
        assertEquals("جدید", saved.title)
        assertEquals(9L, saved.createdAt)
        assertEquals("/covers/new.jpg", saved.coverPath)
        assertEquals(listOf<String?>("/covers/old.jpg"), importer.deletedCovers)
        assertFalse(vm.state.value.isBusy)
    }
}
